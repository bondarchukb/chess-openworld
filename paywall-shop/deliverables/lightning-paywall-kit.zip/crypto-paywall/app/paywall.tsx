"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import QRCode from "qrcode";

type RegisterResp = {
  status: "awaiting_payment";
  order_id: string;
  bolt11: string;
  payment_hash: string;
  verify_url: string;
  amount_sats: number;
  expires_at: number;
};

type ClaimResp = { status: "paid"; ticket_code: string; download_url: string };

type State =
  | { kind: "idle" }
  | { kind: "submitting" }
  | ({ kind: "awaiting_payment" } & RegisterResp & { qrDataUrl: string })
  | { kind: "claiming" }
  | { kind: "paid"; download_url: string; ticket_code: string }
  | { kind: "error"; message: string };

declare global {
  interface Window {
    webln?: { enable: () => Promise<void>; sendPayment: (pr: string) => Promise<{ preimage: string }> };
  }
}

export function Paywall({
  title,
  author,
  description,
  priceSats,
}: {
  title: string;
  author: string;
  description: string;
  priceSats: number;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [state, setState] = useState<State>({ kind: "idle" });
  const [copied, setCopied] = useState(false);
  const pollRef = useRef<number | null>(null);

  const claim = useCallback(async (order_id: string, preimage?: string) => {
    setState({ kind: "claiming" });
    const res = await fetch("/api/claim", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ order_id, preimage }),
    });
    const data = (await res.json()) as ClaimResp | { error: string };
    if (!res.ok || "error" in data) {
      setState({ kind: "error", message: ("error" in data && data.error) || "claim failed" });
      return;
    }
    setState({ kind: "paid", download_url: data.download_url, ticket_code: data.ticket_code });
  }, []);

  useEffect(() => {
    if (state.kind !== "awaiting_payment") return;
    const verify_url = state.verify_url;
    const order_id = state.order_id;
    let stopped = false;

    const tick = async () => {
      try {
        const res = await fetch(verify_url, { cache: "no-store" });
        if (!res.ok) return;
        const data = (await res.json()) as { settled?: boolean; preimage?: string | null };
        if (data.settled && data.preimage && !stopped) {
          stopped = true;
          if (pollRef.current !== null) window.clearInterval(pollRef.current);
          pollRef.current = null;
          await claim(order_id, data.preimage);
        }
      } catch {
        /* ignore */
      }
    };
    pollRef.current = window.setInterval(tick, 2000);
    tick();
    return () => {
      stopped = true;
      if (pollRef.current !== null) window.clearInterval(pollRef.current);
      pollRef.current = null;
    };
  }, [state, claim]);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setState({ kind: "submitting" });
      try {
        const res = await fetch("/api/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email }),
        });
        const data = (await res.json()) as RegisterResp | { error: string };
        if (!res.ok || "error" in data) {
          setState({ kind: "error", message: ("error" in data && data.error) || "register failed" });
          return;
        }
        const qrDataUrl = await QRCode.toDataURL(data.bolt11.toUpperCase(), { margin: 1, width: 320 });
        setState({ kind: "awaiting_payment", qrDataUrl, ...data });
        if (typeof window !== "undefined" && window.webln) {
          try {
            await window.webln.enable();
            await window.webln.sendPayment(data.bolt11);
          } catch {
            /* user dismissed WebLN, fall back to QR */
          }
        }
      } catch (err) {
        setState({ kind: "error", message: err instanceof Error ? err.message : "network error" });
      }
    },
    [name, email],
  );

  const copyInvoice = useCallback(async (bolt11: string) => {
    try {
      await navigator.clipboard.writeText(bolt11);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  }, []);

  return (
    <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-amber-400/10 via-white/5 to-amber-400/5 p-6 md:p-8 shadow-[0_30px_90px_rgba(0,0,0,0.4)]">
      <h1 className="text-3xl md:text-4xl font-bold tracking-tight">{title}</h1>
      {author && <p className="mt-1 text-white/60">by {author}</p>}
      {description && <p className="mt-4 text-white/80 leading-relaxed">{description}</p>}

      <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1.5">
        <span className="text-amber-300 font-semibold">⚡ {priceSats} sats</span>
      </div>

      {(state.kind === "idle" || state.kind === "submitting" || state.kind === "error") && (
        <form onSubmit={submit} className="mt-6 space-y-3">
          <input
            required
            type="text"
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-amber-400/50"
          />
          <input
            required
            type="email"
            placeholder="Your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-amber-400/50"
          />
          <button
            type="submit"
            disabled={state.kind === "submitting"}
            className="w-full rounded-xl bg-amber-400 px-4 py-3 font-semibold text-black hover:bg-amber-300 disabled:opacity-50"
          >
            {state.kind === "submitting" ? "Generating invoice..." : `Pay ${priceSats} sats ⚡`}
          </button>
          {state.kind === "error" && <p className="text-red-400 text-sm">{state.message}</p>}
        </form>
      )}

      {state.kind === "awaiting_payment" && (
        <div className="mt-6 flex flex-col items-center gap-4">
          <div className="rounded-2xl bg-white p-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={state.qrDataUrl} alt="Lightning invoice QR" width={320} height={320} />
          </div>
          <p className="text-white/70 text-sm">Scan with Lightning wallet — auto-detects on settle</p>
          <button
            onClick={() => copyInvoice(state.bolt11)}
            className="rounded-xl border border-white/20 bg-white/5 px-4 py-2 text-sm hover:bg-white/10"
          >
            {copied ? "Copied ✓" : "Copy invoice"}
          </button>
        </div>
      )}

      {state.kind === "claiming" && (
        <div className="mt-6 text-center text-amber-300">Payment received — issuing download...</div>
      )}

      {state.kind === "paid" && (
        <div className="mt-6 rounded-2xl border border-green-400/30 bg-green-400/10 p-5 text-center">
          <p className="text-green-300 font-semibold text-lg">✅ Paid. Enjoy your audiobook.</p>
          <a
            href={state.download_url}
            className="mt-3 inline-block rounded-xl bg-green-400 px-5 py-2.5 font-semibold text-black hover:bg-green-300"
          >
            Download
          </a>
          <p className="mt-2 text-xs text-white/50">Ticket: {state.ticket_code}</p>
        </div>
      )}
    </div>
  );
}
