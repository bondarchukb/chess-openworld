import { Paywall } from "./paywall";

export default function Home() {
  const title = process.env.AUDIOBOOK_TITLE ?? "Audiobook";
  const author = process.env.AUDIOBOOK_AUTHOR ?? "";
  const description = process.env.AUDIOBOOK_DESCRIPTION ?? "";
  const price = Number(process.env.PRICE_SATS ?? "10");
  return (
    <main className="min-h-screen bg-black text-white flex items-center justify-center p-6">
      <div className="w-full max-w-xl">
        <Paywall title={title} author={author} description={description} priceSats={price} />
      </div>
    </main>
  );
}
